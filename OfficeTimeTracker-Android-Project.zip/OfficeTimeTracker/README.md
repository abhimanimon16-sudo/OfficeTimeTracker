# Office Time Tracker (Android)

A simple offline Android app that:
- Lets you choose a date, start time, and end time
- Calculates elapsed working time (no break, overtime, or under-time calculations)
- Saves one record per date on the phone
- Creates Daily and Monthly reports
- Shares reports through Android's share sheet (choose Email, WhatsApp, or another app)

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`OfficeTimeTracker`) in Android Studio.
3. Allow Gradle sync to finish. Android Studio may ask to install Android SDK 35; accept it.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When complete, click **locate** in the notification. The APK is normally at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer the APK to your Android phone and install it. You may need to allow installation from that source.

## Notes
- The app works offline; sharing requires the chosen Email/WhatsApp app and an internet connection if the service needs one.
- The Monthly Report uses the month of the date currently selected.
- If end time is earlier than start time, the app assumes the shift ends after midnight.
- Records are stored locally in app storage and are not automatically backed up or synced.
