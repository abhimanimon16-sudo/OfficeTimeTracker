package com.example.officetimetracker;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TreeMap;

public class MainActivity extends Activity {
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private final SimpleDateFormat prettyDate = new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH);
    private SharedPreferences prefs;
    private TextView dateValue, startValue, endValue, resultValue, recordsValue;
    private Calendar selectedDate = Calendar.getInstance();
    private int startHour = 9, startMinute = 0, endHour = 17, endMinute = 0;
    private String selectedStart = "09:00", selectedEnd = "17:00";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("office_time_records", MODE_PRIVATE);
        buildUi();
        updateDateLabel();
        updateTimeLabels();
        updateSummary();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(28));
        root.setBackgroundColor(0xFFF5F7FA);
        scroll.addView(root);

        TextView title = text("Office Time Tracker", 26, true, 0xFF17324D);
        root.addView(title);
        TextView subtitle = text("Track your daily working hours", 15, false, 0xFF607080);
        LinearLayout.LayoutParams subLp = params(-1, -2); subLp.bottomMargin = dp(20);
        root.addView(subtitle, subLp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackgroundColor(0xFFFFFFFF);
        root.addView(card, params(-1, -2));

        dateValue = text("", 17, true, 0xFF17324D);
        addField(card, "Date", dateValue, "Choose Date", v -> {
            DatePickerDialog dialog = new DatePickerDialog(this, (view, y, m, d) -> {
                selectedDate.set(y, m, d); updateDateLabel();
            }, selectedDate.get(Calendar.YEAR), selectedDate.get(Calendar.MONTH), selectedDate.get(Calendar.DAY_OF_MONTH));
            dialog.show();
        });

        startValue = text("", 17, true, 0xFF17324D);
        addField(card, "Start Time", startValue, "Choose Start Time", v -> {
            new TimePickerDialog(this, (view, h, m) -> {
                startHour = h; startMinute = m; selectedStart = String.format(Locale.US, "%02d:%02d", h, m);
                updateTimeLabels(); calculatePreview();
            }, startHour, startMinute, true).show();
        });

        endValue = text("", 17, true, 0xFF17324D);
        addField(card, "End Time", endValue, "Choose End Time", v -> {
            new TimePickerDialog(this, (view, h, m) -> {
                endHour = h; endMinute = m; selectedEnd = String.format(Locale.US, "%02d:%02d", h, m);
                updateTimeLabels(); calculatePreview();
            }, endHour, endMinute, true).show();
        });

        resultValue = text("0h 00m", 25, true, 0xFF1565C0);
        resultValue.setGravity(Gravity.CENTER);
        resultValue.setPadding(0, dp(14), 0, dp(14));
        card.addView(resultValue, params(-1, -2));

        Button save = button("Save Daily Record");
        LinearLayout.LayoutParams saveLp = params(-1, dp(50)); saveLp.topMargin = dp(12);
        card.addView(save, saveLp);
        save.setOnClickListener(v -> saveRecord());

        TextView reportTitle = text("Reports", 21, true, 0xFF17324D);
        LinearLayout.LayoutParams rt = params(-1, -2); rt.topMargin = dp(22); rt.bottomMargin = dp(10);
        root.addView(reportTitle, rt);

        Button daily = button("Daily Report");
        root.addView(daily, params(-1, dp(48)));
        daily.setOnClickListener(v -> shareReport(makeDailyReport()));

        Button monthly = button("Monthly Report");
        LinearLayout.LayoutParams mlp = params(-1, dp(48)); mlp.topMargin = dp(8);
        root.addView(monthly, mlp);
        monthly.setOnClickListener(v -> shareReport(makeMonthlyReport()));

        recordsValue = text("", 14, false, 0xFF526170);
        LinearLayout.LayoutParams rlp = params(-1, -2); rlp.topMargin = dp(18);
        root.addView(recordsValue, rlp);

        setContentView(scroll);
        calculatePreview();
    }

    private void addField(LinearLayout parent, String label, TextView value, String buttonText, View.OnClickListener listener) {
        TextView heading = text(label, 13, true, 0xFF607080);
        LinearLayout.LayoutParams hp = params(-1, -2); hp.topMargin = dp(10);
        parent.addView(heading, hp);
        parent.addView(value, params(-1, dp(30)));
        Button b = button(buttonText);
        LinearLayout.LayoutParams bp = params(-1, dp(42)); bp.topMargin = dp(4);
        parent.addView(b, bp);
        b.setOnClickListener(listener);
    }

    private TextView text(String value, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        return b;
    }

    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private String dateKey() { return dateFormat.format(selectedDate.getTime()); }
    private void updateDateLabel() { dateValue.setText(prettyDate.format(selectedDate.getTime())); }
    private void updateTimeLabels() { startValue.setText(selectedStart); endValue.setText(selectedEnd); }

    private int durationMinutes(String start, String end) {
        String[] s = start.split(":"), e = end.split(":");
        int a = Integer.parseInt(s[0]) * 60 + Integer.parseInt(s[1]);
        int b = Integer.parseInt(e[0]) * 60 + Integer.parseInt(e[1]);
        if (b < a) b += 24 * 60; // Supports shifts that finish after midnight.
        return b - a;
    }

    private String durationText(int minutes) {
        return (minutes / 60) + "h " + String.format(Locale.US, "%02dm", minutes % 60);
    }

    private void calculatePreview() {
        if (resultValue != null) resultValue.setText("Total: " + durationText(durationMinutes(selectedStart, selectedEnd)));
    }

    private JSONObject loadRecords() {
        try { return new JSONObject(prefs.getString("records", "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    private void saveRecord() {
        try {
            JSONObject records = loadRecords();
            JSONObject record = new JSONObject();
            record.put("start", selectedStart);
            record.put("end", selectedEnd);
            record.put("minutes", durationMinutes(selectedStart, selectedEnd));
            records.put(dateKey(), record);
            prefs.edit().putString("records", records.toString()).apply();
            updateSummary();
            Toast.makeText(this, "Record saved", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not save record", Toast.LENGTH_SHORT).show();
        }
    }

    private String makeDailyReport() {
        String key = dateKey();
        JSONObject records = loadRecords();
        JSONObject r = records.optJSONObject(key);
        if (r == null) return "Office Time Tracker - Daily Report\nDate: " + key + "\nNo saved record for this date.";
        return "Office Time Tracker - Daily Report\nDate: " + key +
                "\nStart Time: " + r.optString("start") +
                "\nEnd Time: " + r.optString("end") +
                "\nTotal Working Hours: " + durationText(r.optInt("minutes"));
    }

    private String makeMonthlyReport() {
        String month = dateKey().substring(0, 7);
        JSONObject records = loadRecords();
        TreeMap<String, JSONObject> sorted = new TreeMap<>();
        JSONArray keys = records.names();
        if (keys != null) for (int i = 0; i < keys.length(); i++) {
            String k = keys.optString(i);
            if (k.startsWith(month)) sorted.put(k, records.optJSONObject(k));
        }
        StringBuilder out = new StringBuilder("Office Time Tracker - Monthly Report\nMonth: " + month + "\n\n");
        int total = 0;
        if (sorted.isEmpty()) out.append("No saved records for this month.\n");
        for (String k : sorted.keySet()) {
            JSONObject r = sorted.get(k);
            int mins = r == null ? 0 : r.optInt("minutes");
            total += mins;
            out.append(k).append(" | ").append(r == null ? "" : r.optString("start"))
               .append(" - ").append(r == null ? "" : r.optString("end"))
               .append(" | ").append(durationText(mins)).append("\n");
        }
        out.append("\nTotal Working Hours: ").append(durationText(total));
        out.append("\nDays Recorded: ").append(sorted.size());
        return out.toString();
    }

    private void shareReport(String report) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "Office Time Tracker Report");
        send.putExtra(Intent.EXTRA_TEXT, report);
        startActivity(Intent.createChooser(send, "Send report using"));
    }

    private void updateSummary() {
        if (recordsValue == null) return;
        JSONObject records = loadRecords();
        String month = dateKey().substring(0, 7);
        int total = 0, days = 0;
        JSONArray keys = records.names();
        if (keys != null) for (int i = 0; i < keys.length(); i++) {
            String k = keys.optString(i);
            if (k.startsWith(month)) {
                JSONObject r = records.optJSONObject(k);
                if (r != null) total += r.optInt("minutes");
                days++;
            }
        }
        recordsValue.setText("This month: " + days + " day(s) recorded • " + durationText(total) +
                "\nRecords are stored on this phone. Reports can be shared by Email or WhatsApp.");
    }
}
